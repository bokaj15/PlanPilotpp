(define (domain openstacks-sequencedstrips-nonADL-nonNegated)
(:requirements :typing :action-costs)
(:types order product count)
(:constants 
 p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14 p15 p16 p17 p18 p19 p20 p21 p22 p23 p24 p25 p26 p27 p28 p29 p30 p31 p32 p33 - product
 o1 o2 o3 o4 o5 o6 o7 o8 o9 o10 o11 o12 o13 o14 o15 o16 o17 o18 o19 o20 o21 o22 o23 o24 o25 o26 o27 o28 o29 o30 o31 o32 o33 - order
)

(:predicates 
	(includes ?o - order ?p - product)
	(waiting ?o - order)
	(started ?o - order)
	(shipped ?o - order)
	(made ?p - product)
	(not-made ?p - product)
	(stacks-avail ?s - count)
	(next-count ?s ?ns - count)
)


(:functions
(total-cost) - number
)

(:action open-new-stack
:parameters (?open ?new-open - count)
:precondition (and (stacks-avail ?open)(next-count ?open ?new-open))
:effect (and (not (stacks-avail ?open))(stacks-avail ?new-open) (increase (total-cost) 1))
)

(:action start-order
:parameters (?o - order ?avail ?new-avail - count)
:precondition (and (waiting ?o)(stacks-avail ?avail)(next-count ?new-avail ?avail))
:effect (and (not (waiting ?o))(started ?o)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1))
)

(:action make-product-p1
:parameters ()
:precondition (and (not-made p1)(started o5)(started o22))
:effect (and (not (not-made p1)) (made p1) (increase (total-cost) 1))
)

(:action make-product-p2
:parameters ()
:precondition (and (not-made p2)(started o16))
:effect (and (not (not-made p2)) (made p2) (increase (total-cost) 1))
)

(:action make-product-p3
:parameters ()
:precondition (and (not-made p3)(started o17))
:effect (and (not (not-made p3)) (made p3) (increase (total-cost) 1))
)

(:action make-product-p4
:parameters ()
:precondition (and (not-made p4)(started o10)(started o22))
:effect (and (not (not-made p4)) (made p4) (increase (total-cost) 1))
)

(:action make-product-p5
:parameters ()
:precondition (and (not-made p5)(started o18))
:effect (and (not (not-made p5)) (made p5) (increase (total-cost) 1))
)

(:action make-product-p6
:parameters ()
:precondition (and (not-made p6)(started o1)(started o21)(started o33))
:effect (and (not (not-made p6)) (made p6) (increase (total-cost) 1))
)

(:action make-product-p7
:parameters ()
:precondition (and (not-made p7)(started o10))
:effect (and (not (not-made p7)) (made p7) (increase (total-cost) 1))
)

(:action make-product-p8
:parameters ()
:precondition (and (not-made p8)(started o16))
:effect (and (not (not-made p8)) (made p8) (increase (total-cost) 1))
)

(:action make-product-p9
:parameters ()
:precondition (and (not-made p9)(started o31))
:effect (and (not (not-made p9)) (made p9) (increase (total-cost) 1))
)

(:action make-product-p10
:parameters ()
:precondition (and (not-made p10)(started o8)(started o18)(started o30))
:effect (and (not (not-made p10)) (made p10) (increase (total-cost) 1))
)

(:action make-product-p11
:parameters ()
:precondition (and (not-made p11)(started o5)(started o12)(started o21)(started o30))
:effect (and (not (not-made p11)) (made p11) (increase (total-cost) 1))
)

(:action make-product-p12
:parameters ()
:precondition (and (not-made p12)(started o5)(started o9))
:effect (and (not (not-made p12)) (made p12) (increase (total-cost) 1))
)

(:action make-product-p13
:parameters ()
:precondition (and (not-made p13)(started o11)(started o19)(started o23)(started o30))
:effect (and (not (not-made p13)) (made p13) (increase (total-cost) 1))
)

(:action make-product-p14
:parameters ()
:precondition (and (not-made p14)(started o26)(started o33))
:effect (and (not (not-made p14)) (made p14) (increase (total-cost) 1))
)

(:action make-product-p15
:parameters ()
:precondition (and (not-made p15)(started o29)(started o30))
:effect (and (not (not-made p15)) (made p15) (increase (total-cost) 1))
)

(:action make-product-p16
:parameters ()
:precondition (and (not-made p16)(started o2)(started o27))
:effect (and (not (not-made p16)) (made p16) (increase (total-cost) 1))
)

(:action make-product-p17
:parameters ()
:precondition (and (not-made p17)(started o8)(started o19)(started o30))
:effect (and (not (not-made p17)) (made p17) (increase (total-cost) 1))
)

(:action make-product-p18
:parameters ()
:precondition (and (not-made p18)(started o4))
:effect (and (not (not-made p18)) (made p18) (increase (total-cost) 1))
)

(:action make-product-p19
:parameters ()
:precondition (and (not-made p19)(started o19))
:effect (and (not (not-made p19)) (made p19) (increase (total-cost) 1))
)

(:action make-product-p20
:parameters ()
:precondition (and (not-made p20)(started o30)(started o32))
:effect (and (not (not-made p20)) (made p20) (increase (total-cost) 1))
)

(:action make-product-p21
:parameters ()
:precondition (and (not-made p21)(started o32))
:effect (and (not (not-made p21)) (made p21) (increase (total-cost) 1))
)

(:action make-product-p22
:parameters ()
:precondition (and (not-made p22)(started o25))
:effect (and (not (not-made p22)) (made p22) (increase (total-cost) 1))
)

(:action make-product-p23
:parameters ()
:precondition (and (not-made p23)(started o10))
:effect (and (not (not-made p23)) (made p23) (increase (total-cost) 1))
)

(:action make-product-p24
:parameters ()
:precondition (and (not-made p24)(started o32))
:effect (and (not (not-made p24)) (made p24) (increase (total-cost) 1))
)

(:action make-product-p25
:parameters ()
:precondition (and (not-made p25)(started o6)(started o7)(started o11)(started o14))
:effect (and (not (not-made p25)) (made p25) (increase (total-cost) 1))
)

(:action make-product-p26
:parameters ()
:precondition (and (not-made p26)(started o15)(started o17))
:effect (and (not (not-made p26)) (made p26) (increase (total-cost) 1))
)

(:action make-product-p27
:parameters ()
:precondition (and (not-made p27)(started o21)(started o24))
:effect (and (not (not-made p27)) (made p27) (increase (total-cost) 1))
)

(:action make-product-p28
:parameters ()
:precondition (and (not-made p28)(started o23))
:effect (and (not (not-made p28)) (made p28) (increase (total-cost) 1))
)

(:action make-product-p29
:parameters ()
:precondition (and (not-made p29)(started o4)(started o7)(started o13)(started o16)(started o20))
:effect (and (not (not-made p29)) (made p29) (increase (total-cost) 1))
)

(:action make-product-p30
:parameters ()
:precondition (and (not-made p30)(started o28))
:effect (and (not (not-made p30)) (made p30) (increase (total-cost) 1))
)

(:action make-product-p31
:parameters ()
:precondition (and (not-made p31)(started o3)(started o28))
:effect (and (not (not-made p31)) (made p31) (increase (total-cost) 1))
)

(:action make-product-p32
:parameters ()
:precondition (and (not-made p32)(started o15)(started o33))
:effect (and (not (not-made p32)) (made p32) (increase (total-cost) 1))
)

(:action make-product-p33
:parameters ()
:precondition (and (not-made p33)(started o13)(started o20))
:effect (and (not (not-made p33)) (made p33) (increase (total-cost) 1))
)

(:action ship-order-o1
:parameters (?avail ?new-avail - count)
:precondition (and (started o1)(made p6)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o1))(shipped o1)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o2
:parameters (?avail ?new-avail - count)
:precondition (and (started o2)(made p16)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o2))(shipped o2)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o3
:parameters (?avail ?new-avail - count)
:precondition (and (started o3)(made p31)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o3))(shipped o3)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o4
:parameters (?avail ?new-avail - count)
:precondition (and (started o4)(made p18)(made p29)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o4))(shipped o4)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o5
:parameters (?avail ?new-avail - count)
:precondition (and (started o5)(made p1)(made p11)(made p12)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o5))(shipped o5)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o6
:parameters (?avail ?new-avail - count)
:precondition (and (started o6)(made p25)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o6))(shipped o6)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o7
:parameters (?avail ?new-avail - count)
:precondition (and (started o7)(made p25)(made p29)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o7))(shipped o7)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o8
:parameters (?avail ?new-avail - count)
:precondition (and (started o8)(made p10)(made p17)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o8))(shipped o8)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o9
:parameters (?avail ?new-avail - count)
:precondition (and (started o9)(made p12)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o9))(shipped o9)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o10
:parameters (?avail ?new-avail - count)
:precondition (and (started o10)(made p4)(made p7)(made p23)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o10))(shipped o10)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o11
:parameters (?avail ?new-avail - count)
:precondition (and (started o11)(made p13)(made p25)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o11))(shipped o11)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o12
:parameters (?avail ?new-avail - count)
:precondition (and (started o12)(made p11)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o12))(shipped o12)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o13
:parameters (?avail ?new-avail - count)
:precondition (and (started o13)(made p29)(made p33)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o13))(shipped o13)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o14
:parameters (?avail ?new-avail - count)
:precondition (and (started o14)(made p25)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o14))(shipped o14)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o15
:parameters (?avail ?new-avail - count)
:precondition (and (started o15)(made p26)(made p32)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o15))(shipped o15)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o16
:parameters (?avail ?new-avail - count)
:precondition (and (started o16)(made p2)(made p8)(made p29)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o16))(shipped o16)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o17
:parameters (?avail ?new-avail - count)
:precondition (and (started o17)(made p3)(made p26)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o17))(shipped o17)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o18
:parameters (?avail ?new-avail - count)
:precondition (and (started o18)(made p5)(made p10)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o18))(shipped o18)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o19
:parameters (?avail ?new-avail - count)
:precondition (and (started o19)(made p13)(made p17)(made p19)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o19))(shipped o19)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o20
:parameters (?avail ?new-avail - count)
:precondition (and (started o20)(made p29)(made p33)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o20))(shipped o20)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o21
:parameters (?avail ?new-avail - count)
:precondition (and (started o21)(made p6)(made p11)(made p27)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o21))(shipped o21)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o22
:parameters (?avail ?new-avail - count)
:precondition (and (started o22)(made p1)(made p4)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o22))(shipped o22)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o23
:parameters (?avail ?new-avail - count)
:precondition (and (started o23)(made p13)(made p28)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o23))(shipped o23)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o24
:parameters (?avail ?new-avail - count)
:precondition (and (started o24)(made p27)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o24))(shipped o24)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o25
:parameters (?avail ?new-avail - count)
:precondition (and (started o25)(made p22)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o25))(shipped o25)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o26
:parameters (?avail ?new-avail - count)
:precondition (and (started o26)(made p14)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o26))(shipped o26)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o27
:parameters (?avail ?new-avail - count)
:precondition (and (started o27)(made p16)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o27))(shipped o27)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o28
:parameters (?avail ?new-avail - count)
:precondition (and (started o28)(made p30)(made p31)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o28))(shipped o28)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o29
:parameters (?avail ?new-avail - count)
:precondition (and (started o29)(made p15)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o29))(shipped o29)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o30
:parameters (?avail ?new-avail - count)
:precondition (and (started o30)(made p10)(made p11)(made p13)(made p15)(made p17)(made p20)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o30))(shipped o30)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o31
:parameters (?avail ?new-avail - count)
:precondition (and (started o31)(made p9)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o31))(shipped o31)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o32
:parameters (?avail ?new-avail - count)
:precondition (and (started o32)(made p20)(made p21)(made p24)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o32))(shipped o32)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

(:action ship-order-o33
:parameters (?avail ?new-avail - count)
:precondition (and (started o33)(made p6)(made p14)(made p32)(stacks-avail ?avail)(next-count ?avail ?new-avail))
:effect (and (not (started o33))(shipped o33)(not (stacks-avail ?avail))(stacks-avail ?new-avail) (increase (total-cost) 1)))

)

